import React from 'react'

const PaymentSuccess = () => {
    return (
        <strong>Payment Done Successfully</strong>
    )
}

export default PaymentSuccess